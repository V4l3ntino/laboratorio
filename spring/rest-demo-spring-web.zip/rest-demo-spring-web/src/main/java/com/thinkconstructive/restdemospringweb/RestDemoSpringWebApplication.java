package com.thinkconstructive.restdemospringweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestDemoSpringWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestDemoSpringWebApplication.class, args);
	}

}
