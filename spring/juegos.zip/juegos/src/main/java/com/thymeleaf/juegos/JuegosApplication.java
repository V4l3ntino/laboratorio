package com.thymeleaf.juegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuegosApplication.class, args);
	}

}
